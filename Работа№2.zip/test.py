import pygame
import os
import sys

pygame.init()
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
SIZE = WIDTH, HEIGHT = screen.get_size()
FPS = 50
tiles = {'$': 'floor_1.png', '@': "floor_8.png", '^': 'floor_2.png', '*': 'floor_7.png',
         '(': 'floor_4.png', '№': 'floor_3.png', ')': 'floor_5.png', '+': 'floor_6.png',
         '>': 'floor_ladder.png', '<': 'hole.png', "#": 'wall_hole_1.png', "!": "wall_mid.png",
         "%": "wall_banner_green.png", '|': 'wall_side_front_left.png', '\\': "wall_side_front_right.png",
         "Q": "wall_fountain_basin_red_anim_f2.png", "A": "wall_fountain_basin_blue_anim_f2.png"}
decor = {"H": "column_top.png", "M": "column_mid.png", "L": "coulmn_base.png", "S": "wall_side_mid_left.png",
         "P": "wall_side_mid_right.png", "T": "wall_left.png", "C": "wall_mid.png", "R": "wall_corner_right.png",
         "O": "wall_corner_left.png", "_": "wall_top_mid.png", "I": "wall_inner_corner_l_top_left.png",
         "U": "wall_inner_corner_l_top_rigth.png", "J": "wall_corner_top_left.png", "G": "wall_corner_top_right.png",
         "W": "wall_fountain_mid_red_anim_f2.png", "E": "wall_fountain_mid_blue_anim_f2.png",
         "D": "doors_leaf_closed.png", "B": "crate.png", "V": "chest_empty_open_anim_f0.png",
         "N": "wall_right.png"}
tile_width = tile_height = 45


def load_image(file, colorkey=None):
    fullname = os.path.join('data', file)
    if not os.path.isfile(fullname):
        print("Файл не обнаружен")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is None:
        image = image.convert_alpha()
    else:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    return image


def load_level(filename):
    filename = "data/" + filename
    if not os.path.isfile(filename):
        print('Файл не найден')
        sys.exit()
    with open(filename, 'r', encoding='utf-8') as mapFile:
        level_map = [line.strip() for line in mapFile]
    max_width = max(map(len, level_map))
    return list(map(lambda x: x.ljust(max_width, '.'), level_map))


class Flour(pygame.sprite.Sprite):
    def __init__(self, type, x, y):
        if type in "!#|%\\":
            super().__init__(wall_sprites, all_sprites)
        else:
            super().__init__(tile_sprites, all_sprites)
        self.type = type
        self.image = pygame.transform.scale(load_image(tiles[type]), (50, 50))
        self.rect = self.image.get_rect().move(x * tile_width, y * tile_height)


class Decor(pygame.sprite.Sprite):
    def __init__(self, type, x, y):
        if type == "D":
            super(Decor, self).__init__(all_sprites, door_sprites)
        elif type in "HL":
            super(Decor, self).__init__(all_sprites, column_sprites)
        else:
            super(Decor, self).__init__(all_sprites, decor_sprites)
        self.type = type
        if type != "D":
            self.image = pygame.transform.scale(load_image(decor[type]), (50, 50))
        else:
            self.image = pygame.transform.scale(load_image(decor[type]), (100, 100))
        self.rect = self.image.get_rect().move(x * tile_width, y * tile_height)
        self.mask = pygame.mask.from_surface(self.image)


class BlueFountain(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super(BlueFountain, self).__init__(all_sprites, blue_fountain)
        self.list_image = ["wall_fountain_mid_blue_anim_f0.png", "wall_fountain_mid_blue_anim_f1.png",
                           "wall_fountain_mid_blue_anim_f2.png"]
        self.number = 0
        self.image = pygame.transform.scale(load_image(self.list_image[self.number % 3]), (50, 50))
        self.rect = self.image.get_rect().move(x * tile_width, y * tile_height)

    def update(self):
        self.number += 0.2
        self.image = pygame.transform.scale(load_image(self.list_image[int(self.number) % 3]), (50, 50))


class BlueFountainFloor(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super(BlueFountainFloor, self).__init__(all_sprites, blue_fountain_floor, tile_sprites)
        self.list_image = ["wall_fountain_basin_blue_anim_f0.png", "wall_fountain_basin_blue_anim_f1.png",
                           "wall_fountain_basin_blue_anim_f2.png"]
        self.number = 0
        self.image = pygame.transform.scale(load_image(self.list_image[self.number % 3]), (50, 50))
        self.rect = self.image.get_rect().move(x * tile_width, y * tile_height)

    def update(self):
        self.number += 0.2
        self.image = pygame.transform.scale(load_image(self.list_image[int(self.number) % 3]), (50, 50))


class RedFountain(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super(RedFountain, self).__init__(all_sprites, red_fountain)
        self.list_image = ["wall_fountain_mid_red_anim_f0.png", "wall_fountain_mid_red_anim_f1.png",
                           "wall_fountain_mid_red_anim_f2.png"]
        self.number = 0
        self.image = pygame.transform.scale(load_image(self.list_image[self.number % 3]), (50, 50))
        self.rect = self.image.get_rect().move(x * tile_width, y * tile_height)

    def update(self):
        self.number += 0.2
        self.image = pygame.transform.scale(load_image(self.list_image[int(self.number) % 3]), (50, 50))


class RedFountainFloor(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super(RedFountainFloor, self).__init__(all_sprites, red_fountain_floor, tile_sprites)
        self.list_image = ["wall_fountain_basin_red_anim_f0.png", "wall_fountain_basin_red_anim_f1.png",
                           "wall_fountain_basin_red_anim_f2.png"]
        self.number = 0
        self.image = pygame.transform.scale(load_image(self.list_image[self.number % 3]), (50, 50))
        self.rect = self.image.get_rect().move(x * tile_width, y * tile_height)

    def update(self):
        self.number += 0.2
        self.image = pygame.transform.scale(load_image(self.list_image[int(self.number) % 3]), (50, 50))


class Player(pygame.sprite.Sprite):
    player = "knight_f_idle_anim_f3.png"

    def __init__(self):
        super(Player, self).__init__(all_sprites, player_sprites)
        self.image = pygame.transform.scale(load_image(Player.player), (50, 100))
        self.rect = self.image.get_rect().move(10 * tile_width, 11 * tile_height)
        self.mask = pygame.mask.from_surface(self.image)

    def update(self, x, y):
        self.rect.x += x
        self.rect.y += y
        for event in decor_sprites:
            if pygame.sprite.collide_mask(self, event):
                self.rect.x -= x
                self.rect.y -= y
                return
        for event in wall_sprites:
            if pygame.sprite.collide_mask(self, event):
                self.rect.x -= x
                self.rect.y -= y
                return
        for event in door_sprites:
            if pygame.sprite.collide_mask(self, event):
                self.rect.x -= x
                self.rect.y -= y
                return


def generate_level(level):
    x, y, player = None, None, None
    for i in range(len(level)):
        for ii in range(len(level[0])):
            if level[i][ii] == "A":
                BlueFountainFloor(ii, i)
            elif level[i][ii] == 'Q':
                RedFountainFloor(ii, i)
            elif level[i][ii] in list(tiles):
                Flour(level[i][ii], ii, i)
            elif level[i][ii] == "E":
                BlueFountain(ii, i)
            elif level[i][ii] == "W":
                RedFountain(ii, i)
            elif level[i][ii] in list(decor):
                Decor(level[i][ii], ii, i)


def terminate():
    pygame.quit()
    sys.exit()


running = True
clock = pygame.time.Clock()
all_sprites = pygame.sprite.Group()
tile_sprites = pygame.sprite.Group()
door_sprites = pygame.sprite.Group()
wall_sprites = pygame.sprite.Group()
decor_sprites = pygame.sprite.Group()
player_sprites = pygame.sprite.Group()
column_sprites = pygame.sprite.Group()
blue_fountain = pygame.sprite.Group()
red_fountain = pygame.sprite.Group()
blue_fountain_floor = pygame.sprite.Group()
red_fountain_floor = pygame.sprite.Group()
player = Player()
generate_level(load_level('level.txt'))
generate_level(load_level('decor_level.txt'))
dic = {"right": False, "left": False, "top": False, "down": False}
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            terminate()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                terminate()
                running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                dic['right'] = True
            if event.key == pygame.K_LEFT:
                dic['left'] = True
            if event.key == pygame.K_UP:
                dic["top"] = True
            if event.key == pygame.K_DOWN:
                dic["down"] = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_RIGHT:
                dic['right'] = False
            if event.key == pygame.K_LEFT:
                dic['left'] = False
            if event.key == pygame.K_UP:
                dic["top"] = False
            if event.key == pygame.K_DOWN:
                dic["down"] = False
    if dic['right']:
        player.update(10, 0)
    if dic['left']:
        player.update(-10, 0)
    if dic["top"]:
        player.update(0, -10)
    if dic['down']:
        player.update(0, 10)
    screen.fill('black')
    tile_sprites.draw(screen)
    wall_sprites.draw(screen)
    player_sprites.draw(screen)
    decor_sprites.draw(screen)
    door_sprites.draw(screen)
    column_sprites.draw(screen)
    blue_fountain.draw(screen)
    red_fountain.draw(screen)
    for i in blue_fountain:
        i.update()
    for i in red_fountain:
        i.update()
    for i in blue_fountain_floor:
        i.update()
    for i in red_fountain_floor:
        i.update()
    pygame.display.flip()
    clock.tick(30)
pygame.quit()